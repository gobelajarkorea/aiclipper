# AutoClipper AI Android

Aplikasi Android untuk mencari bagian penting dari video secara otomatis menggunakan Gemini API.

Alur:
1. Masukkan Gemini API key pada aplikasi.
2. Pilih video dari galeri.
3. AI menganalisis video dan mengembalikan beberapa segmen paling menarik dalam JSON.
4. Aplikasi menampilkan daftar clip dengan skor dan alasan.
5. Pilih clip lalu export MP4 menggunakan Media3.

Catatan:
- API key dipakai dari perangkat dan jangan dibagikan.
- Video dikirim ke Gemini API. Pastikan Anda berhak mengunggah video tersebut.
- Dukungan URL YouTube langsung untuk proses download belum diaktifkan pada build ini. Gemini dapat memahami URL YouTube publik untuk analisis, tetapi proses render clip membutuhkan file video lokal.
- Untuk video besar/panjang, Gemini merekomendasikan Files API.

Build:
Project memiliki GitHub Actions untuk membuat APK debug.
