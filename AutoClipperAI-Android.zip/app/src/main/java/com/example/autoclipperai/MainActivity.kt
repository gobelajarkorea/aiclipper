package com.example.autoclipperai

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.MultipartBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

@UnstableApi
class MainActivity : AppCompatActivity() {
    private var videoUri: Uri? = null
    private lateinit var apiKey: EditText
    private lateinit var fileText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var results: LinearLayout
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .build()

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let {
            videoUri = it
            fileText.text = "Video dipilih: $it"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        apiKey = findViewById(R.id.apiKey)
        fileText = findViewById(R.id.fileText)
        progress = findViewById(R.id.progress)
        results = findViewById(R.id.results)

        findViewById<Button>(R.id.pickButton).setOnClickListener {
            picker.launch("video/*")
        }
        findViewById<Button>(R.id.analyzeButton).setOnClickListener {
            analyze()
        }
    }

    private fun analyze() {
        val key = apiKey.text.toString().trim()
        val uri = videoUri
        if (key.isBlank()) { toast("Masukkan Gemini API Key"); return }
        if (uri == null) { toast("Pilih video"); return }

        progress.visibility = View.VISIBLE
        results.removeAllViews()

        lifecycleScope.launch {
            try {
                val json = withContext(Dispatchers.IO) {
                    uploadAndAnalyze(key, uri)
                }
                progress.visibility = View.GONE
                renderResults(json)
            } catch (e: Exception) {
                progress.visibility = View.GONE
                toast("Gagal: ${e.message}")
            }
        }
    }

    private fun uploadAndAnalyze(key: String, uri: Uri): JSONObject {
        val temp = File(cacheDir, "input_${System.currentTimeMillis()}.mp4")
        contentResolver.openInputStream(uri)!!.use { input ->
            temp.outputStream().use { out -> input.copyTo(out) }
        }

        val bytes = temp.readBytes()
        if (bytes.size > 100 * 1024 * 1024) {
            // The File API is preferable for large files. This build keeps the implementation simple.
            throw IllegalArgumentException("Video >100MB. Gunakan video lebih kecil untuk build ini.")
        }

        val mime = contentResolver.getType(uri) ?: "video/mp4"
        val prompt = """
            Analyze this video for short-form content.
            Find up to 8 of the most important, useful, emotional, surprising, funny,
            or highly engaging segments. Prefer self-contained clips 20-90 seconds long.
            Avoid dead air, introductions, repetitive sections, and incomplete sentences.
            Return ONLY JSON matching:
            {
              "clips":[
                {
                  "start": number,
                  "end": number,
                  "score": number,
                  "title": string,
                  "reason": string
                }
              ]
            }
            Timestamps must be seconds from the start of the video.
            Score is 0-100.
        """.trimIndent()

        val uploadUrl = "https://generativelanguage.googleapis.com/upload/v1beta/files?key=$key"
        val body = RequestBody.create(mime.toMediaType(), bytes)
        val uploadReq = Request.Builder()
            .url(uploadUrl)
            .addHeader("X-Goog-Upload-Protocol", "raw")
            .addHeader("X-Goog-Upload-File-Name", temp.name)
            .post(body).build()

        val uploadResp = client.newCall(uploadReq).execute()
        if (!uploadResp.isSuccessful) throw IllegalStateException("Upload API: ${uploadResp.code}")
        val uploadJson = JSONObject(uploadResp.body!!.string())
        val file = uploadJson.optJSONObject("file") ?: throw IllegalStateException("File upload gagal")
        val fileUri = file.getString("uri")
        val fileName = file.getString("name")
        var state = file.optString("state")

        while (state != "ACTIVE") {
            Thread.sleep(3000)
            val r = client.newCall(
                Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/$fileName?key=$key").get().build()
            ).execute()
            val j = JSONObject(r.body!!.string())
            state = j.optString("state")
            if (state == "FAILED") throw IllegalStateException("Gemini gagal memproses video")
        }

        val input = JSONObject()
        input.put("contents", org.json.JSONArray().put(
            JSONObject().apply {
                put("parts", org.json.JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("file_data", JSONObject()
                        .put("mime_type", mime).put("file_uri", fileUri))))
            }
        ))
        input.put("generationConfig", JSONObject()
            .put("responseMimeType", "application/json"))

        val genReq = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
            .post(RequestBody.create("application/json".toMediaType(), input.toString()))
            .build()
        val genResp = client.newCall(genReq).execute()
        if (!genResp.isSuccessful) throw IllegalStateException("Gemini API: ${genResp.code}")
        val out = JSONObject(genResp.body!!.string())
        val text = out.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        temp.delete()
        return JSONObject(text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
    }

    private fun renderResults(json: JSONObject) {
        val clips = json.getJSONArray("clips")
        for (i in 0 until clips.length()) {
            val c = clips.getJSONObject(i)
            val title = c.getString("title")
            val start = c.getDouble("start")
            val end = c.getDouble("end")
            val score = c.getInt("score")
            val reason = c.getString("reason")

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16,16,16,16)
            }
            val t = TextView(this).apply {
                text = "#${i+1}  $title\n${formatTime(start)} → ${formatTime(end)}  •  Score $score/100\n$reason"
                textSize = 16f
            }
            val b = Button(this).apply {
                text = "✂ Buat Clip"
                setOnClickListener { exportClip(start, end, i+1) }
            }
            card.addView(t)
            card.addView(b)
            results.addView(card)
        }
    }

    private fun exportClip(start: Double, end: Double, index: Int) {
        val uri = videoUri ?: return
        val output = File(cacheDir, "clip_${System.currentTimeMillis()}.mp4")
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs((start*1000).toLong())
                .setEndPositionMs((end*1000).toLong()).build()
        ).build()
        val edited = EditedMediaItem.Builder(item).build()
        progress.visibility = View.VISIBLE

        val transformer = Transformer.Builder(this)
            .addListener(object: Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, result: ExportResult) {
                    saveVideo(output, index)
                }
                override fun onError(composition: androidx.media3.transformer.Composition, result: ExportResult, exception: ExportException) {
                    progress.visibility = View.GONE
                    toast("Export gagal: ${exception.message}")
                }
            }).build()
        transformer.start(edited, output.absolutePath)
    }

    private fun saveVideo(file: File, index: Int) {
        lifecycleScope.launch(Dispatchers.IO) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "AutoClip_${index}_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AutoClipper")
            }
            val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            if (dest != null) contentResolver.openOutputStream(dest)!!.use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
            }
            file.delete()
            withContext(Dispatchers.Main) {
                progress.visibility = View.GONE
                toast("Clip #$index tersimpan di Movies/AutoClipper")
            }
        }
    }

    private fun formatTime(s: Double): String {
        val total = s.toInt()
        return "%02d:%02d".format(total/60, total%60)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
